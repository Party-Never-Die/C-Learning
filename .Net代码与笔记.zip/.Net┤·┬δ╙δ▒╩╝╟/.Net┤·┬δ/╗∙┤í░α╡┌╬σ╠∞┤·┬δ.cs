﻿using System;

namespace 基础班第五天代码
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            //向控制台输出10个今天天气不错   
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("今天天气不错");
                
         
            
            }


            

            //for循环的正序与倒叙
            //倒叙使用forr+tab+tab可以快捷输入  
            //控制台打印10-1
            for (int i = 10; i >= 1; i--)
            {
                Console.WriteLine(i);
            }

            


            //for循环，求1-100之间的整数和  偶数和  奇数和
            //整数和
            int sum = 0;
            for (int i = 1; i <= 100; i++)
            {
                sum += i;
                
            }

            Console.WriteLine("1-100所有整数和为：{0}",sum);
            Console.ReadKey();
             

            //奇数和
            int sum = 0;
            for (int i = 1; i <=100; i+=2)
            {
                sum += i;
            }
            Console.WriteLine("1-100所有整数和为：{0}", sum);
            Console.ReadKey();

           

            //偶数和
            int sum = 0;
            for (int i = 0; i <= 100; i += 2)
            {
                sum += i;
            }
            Console.WriteLine("1-100所有整数和为：{0}", sum);
            Console.ReadKey();
            

            //找出100-999之间所有的水仙花数
            //水仙花数是指 个位十位百位的数字的立方和仍等于这个数本身
            //如何列出个位十位百位？如 256
            //百位用这个数除100即可 256/100=2
            //十位      256%100/10=5
            //个位      256%10=6
            for (int i = 100; i <= 999; i++)
            {
                int bai=i/ 100 , shi=i%100/10, ge=i%10;    //为存储个十百位赋予变量
                if (bai*bai*bai+shi*shi*shi+ge*ge*ge==i)
                {
                    Console.WriteLine("水仙花数有{0}",i);   //输出水仙花数
                
                }
            }
            Console.ReadKey();

            


            //for循环的嵌套
            //输出乘法口诀表
            for (int i = 1; i < 10; i++)
            {
                for (int j = 1; j < 10; j++)
                {
                    Console.Write("{0}*{1}={2}\t", i,j,i*j);//整行输出 与WriteLine不同
                }
                Console.Write("\n");                        //换行与console.WriteLine();一样
            }

            Console.ReadKey();


             
            //输出半乘法口诀表
            for (int i = 1; i < 10; i++)
            {
                for (int j = 1; j <=i; j++)
                {
                  Console.Write("{0}*{1}={2}\t", i, j, i * j);//整行输出 与WriteLine不同
                }
                Console.Write("\n");                        //换行与console.WriteLine();一样
            }
            Console.ReadKey();

            

            //让用户输入一个值，完乘倒序相加的程序的结果仍然为6
            Console.WriteLine("请输入一个数字");
            try
            {
                int number = Convert.ToInt32(Console.ReadLine());
                for (int i = 0; i <= number; i++)
                {
                    Console.WriteLine("{0}+{1}={2}", i, number-i, i + number);
                }
            }
            catch 
            {
                Console.WriteLine("输入的数字类型不正确");
            }

            


            //类型转换 int.TryParse 、int.parse
            //Convert.ToDouble 转换失败会抛异常比较麻烦
            //本质上就是调用int.Parse double.Parse 等
            int number = int.Parse("123abc");
            Console.WriteLine(number);
            Console.ReadKey();
            
            //int.TryParse 类型转换
            //该方法会返回一个布尔值
            bool b=int.TryParse("123abc", out int number);
            Console.WriteLine(b);
            Console.WriteLine(number);
            Console.ReadKey();
           




            //for循环的三个练习
            //1.循环录入五个人的年龄并计算平均年龄
            //如果录入年龄大于100或者负数则报错并停止输入
            int sum = 0, age = 0;
            bool b = true;                      //对于有选择的输出则通过布尔类型的值来输出
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("请输入你的年龄");
                try
                {
                    age = Convert.ToInt32(Console.ReadLine());
                    if (age <= 0 || age > 100)  //输入的年龄格式不对则退出
                    {
                        Console.WriteLine("输入的年龄有误,程序退出");
                        b = false;
                        break;
                    }
                    sum += age;

                }
                catch
                {
                    Console.WriteLine("输入的年龄有误,程序退出");
                    b = false;
                    break;
                }
            }
            if (b)
            {
                Console.WriteLine("平均年龄为{0}", sum / 5);
            }
            Console.ReadKey();


            
            //2.要求用户一直输入用户名与密码   while-break
            //如果不是admin 与8888则提示一直输入
            string account = "", password = "";
            while (true)
            {
                Console.WriteLine("请输入用户名");
                account=Console.ReadLine();
                Console.WriteLine("请输入密码");
                password = Console.ReadLine();
                if (account == "admin" && password == "8888")
                {

                    break;

                }
                else
                {
                    Console.WriteLine("账号或密码错误，请重新输入");


                }
            
            }
            Console.WriteLine("登陆成功");
            Console.ReadKey();
            


            //1-100之间的整数相加，得到累加值大于20的值，并输出此时该整数
            int sum = 0,i=1;
            for (; i <=100; i++)
            {
                sum += i;
                if (sum > 20)
                {
                    
                    break;
                }
            }
            Console.WriteLine("大于20的整数是{0}",i);
           

            */
            //求1-100之间所有的质数
            
            for (int i = 2; i <= 100; i++)
            {
                bool b = true;
                for (int j = 2; j < i; j++)
                {
                    if (i % j == 0)
                    {
                        b = false;
                        break;
                    
                    }



              
                }
                if (b)
                {
                    Console.WriteLine(i);

                }
               

            }
            Console.ReadKey();










        }
    }
}
